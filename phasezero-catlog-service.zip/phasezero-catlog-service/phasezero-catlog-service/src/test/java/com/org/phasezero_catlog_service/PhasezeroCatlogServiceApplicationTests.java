package com.org.phasezero_catlog_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhasezeroCatlogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
