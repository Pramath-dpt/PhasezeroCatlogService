package com.org.phasezero_catlog_service.Repository;

import com.org.phasezero_catlog_service.Product;

import java.util.List;
import java.util.Optional;

public interface ProductRepository {

    Product save(Product product);

    Optional<Product> findByPartNumber(String partNumber);

    List<Product> findAll();
}
