package com.org.phasezero_catlog_service.service;

import com.org.phasezero_catlog_service.Product;
import com.org.phasezero_catlog_service.Repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // 1) Add new product
    public Product addProduct(Product product) {
        // validations
        if (product.getPartNumber() == null || product.getPartNumber().isBlank()) {
            throw new IllegalArgumentException("partNumber is required");
        }
        if (product.getPartName() == null || product.getPartName().isBlank()) {
            throw new IllegalArgumentException("partName is required");
        }
        if (product.getCategory() == null || product.getCategory().isBlank()) {
            throw new IllegalArgumentException("category is required");
        }
        if (product.getPrice() < 0) {
            throw new IllegalArgumentException("price is not acceptable");
        }

        if (product.getStock() < 0) {
            throw new IllegalArgumentException("stock is not acceptable");
        }

        // ensure lowercase name
        product.setPartName(product.getPartName());

        // check duplicate partNumber
        productRepository.findByPartNumber(product.getPartNumber())
                .ifPresent(existing -> {
                    throw new IllegalStateException(
                            "Product with partNumber '" + product.getPartNumber() + "' already exists"
                    );
                });

        return productRepository.save(product);
    }

    // 2) Get all products
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // 3) Search by partName containing text
    public List<Product> searchByName(String text) {
        String searchText = text.toLowerCase(Locale.ROOT);
        return productRepository.findAll().stream()
                .filter(p -> p.getPartName() != null &&
                        p.getPartName().toLowerCase(Locale.ROOT).contains(searchText))
                .collect(Collectors.toList());
    }

    // 4) Filter by category (case-insensitive)
    public List<Product> filterByCategory(String category) {
        String catLower = category.toLowerCase(Locale.ROOT);
        return productRepository.findAll().stream()
                .filter(p -> p.getCategory() != null &&
                        p.getCategory().toLowerCase(Locale.ROOT).equals(catLower))
                .collect(Collectors.toList());
    }

    // 5) Sort by price ascending
    public List<Product> sortByPriceAsc() {
        return productRepository.findAll().stream()
                .sorted(Comparator.comparing(Product::getPrice))
                .collect(Collectors.toList());
    }

    // 6) Total inventory value
    public double getTotalInventoryValue() {
        return productRepository.findAll().stream()
                .mapToDouble(p -> p.getPrice() * p.getStock())
                .sum();
    }
}

