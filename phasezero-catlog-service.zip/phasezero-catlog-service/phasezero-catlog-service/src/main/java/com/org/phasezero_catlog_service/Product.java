package com.org.phasezero_catlog_service;

public class Product {

    private Long id;          // internal ID
    private String partNumber;
    private String partName;
    private String category;
    private double price;
    private int stock;

    public Product() {
    }

    public Product(Long id, String partNumber, String partName,
                   String category, double price, int stock) {
        this.id = id;
        this.partNumber = partNumber;
        setPartName(partName); // ensures lowercase
        this.category = category;
        this.price = price;
        this.stock = stock;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    // store partName always in lowercase
    public void setPartName(String partName) {
        if (partName != null) {
            this.partName = partName.toLowerCase();
        } else {
            this.partName = null;
        }
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}
