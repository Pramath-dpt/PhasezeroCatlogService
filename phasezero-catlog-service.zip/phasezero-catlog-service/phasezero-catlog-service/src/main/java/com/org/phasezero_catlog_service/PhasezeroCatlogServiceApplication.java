package com.org.phasezero_catlog_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhasezeroCatlogServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhasezeroCatlogServiceApplication.class, args);
	}

}
