package com.org.phasezero_catlog_service.controller;

import com.org.phasezero_catlog_service.Product;
import com.org.phasezero_catlog_service.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // 1) Add new product  (POST /products)
    @PostMapping
    public ResponseEntity<?> addProduct(@RequestBody Product product) {
        try {
            Product saved = productService.addProduct(product);
            return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        } catch (IllegalArgumentException e) {
            // 400 with simple message
            Map<String, String> body = new HashMap<>();
            body.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        } catch (IllegalStateException e) {
            // 409 with simple message for duplicate partNumber
            Map<String, String> body = new HashMap<>();
            body.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
        }
    }

    // 2) List all products (GET /products)
    @GetMapping
    public List<Product> listAllProducts() {
        return productService.getAllProducts();
    }

    // 3) Search by name (GET /products/search?name=text)
    @GetMapping("/search")
    public List<Product> searchByName(@RequestParam("name") String name) {
        return productService.searchByName(name);
    }

    // 4) Filter by category (GET /products/filter?category=filter)
    @GetMapping("/filter")
    public List<Product> filterByCategory(@RequestParam("category") String category) {
        return productService.filterByCategory(category);
    }

    // 5) Sort by price (GET /products/sort/price)
    @GetMapping("/sort/price")
    public List<Product> sortByPrice() {
        return productService.sortByPriceAsc();
    }

    // 6) Total inventory value (GET /products/inventory/value)
    @GetMapping("/inventory/value")
    public double getInventoryValue() {
        return productService.getTotalInventoryValue();
    }
}
